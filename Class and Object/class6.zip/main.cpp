#include<iostream>
#include<string>
using namespace std;
class book{
	public:
		int bid;
		string bname;
		book(int id,string n){
		bid=id;
		bname=n;
		}	
		void display(){
			cout<<"book name : "<<bname<<endl<<"book id :"<<bid<<endl;	
		}		
};
int main(){
	book A(1,"hello");
	book B(2,"world");
	A.display();
	B.display();
}